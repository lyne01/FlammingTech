import sqlite3
from sqlite3 import Error
from tabulate import tabulate
from databasefile import *

try:
    create_database()


except:
    print("Cannot import the Sqlite module or it is not installed in your computer!!!")


# all  about the bookies
def make_booking():
    connect = sqlite3.connect('taxdatabase.db')
    cursor = connect.cursor()
    cursor.execute("SELECT * FROM drivers")
    results = cursor.fetchall()
    dr = []
    print("Available Drivers:")
    for result in results:
        print(result[0])
    print("\n")
    print("Choice by entering 1,2,3 or 4 below")
    dr_choice = input("1. Mr. Right, 2. Mr. Perfect, 3. Mr. GoogleMap, 4. Mr. Route: ")
    print("\n")
    if not dr_choice.isnumeric() or (int(dr_choice) > 4 or int(dr_choice) < 0):
        print("Wrong driver choice choice!")
        make_booking()
    else:
        addr = input("Enter your picking address: ")
        dest = input("Enter your final destination: ")
        datee = input("Enter the booking date: ")
        time = input("Enter the time to be picked: ")
        datas = (dr_choice, addr, dest, datee, time)
        if addr == "" or dest == "" or datee == "" or time == "":
            print("Kindly, all fields are required during bookings")
            make_booking()
        else:
            connection = sqlite3.connect('taxdatabase.db')
            cursor = connection.cursor()
            sql = (
                """ INSERT INTO bookingss (driver, address, destination, date , time) VALUES (?, ?, ?,?,?)""")
            cursor.execute(sql, datas)
            connection.commit()
            cursor.close()
            print("\n")
            print("YOUR BOOKINGS HAS BEEN CREATED SUCCESSFULLY!")
            print("\n")
            input("Press any key to confirm....\n")
            print("\n")
            BOOKINGS()


def view_booking():
    database = sqlite3.connect('taxdatabase.db')
    connection = database.cursor()
    results = connection.execute('SELECT * FROM bookingss')
    print(tabulate(results, headers=['DriverID', 'Address', 'Destination', 'Date', 'Time'], tablefmt='psql'))
    print('\n\n')
    input("Press any key to continue with your bookings!.......")
    print('\n\n')
    BOOKINGS()


def cancel_booking():
    can_bookingdb()
    BOOKINGS()


def BOOKINGS():
    booking_choice = input(
        "Press 1 to Make Bookings:\nPress 2 to View your current booking :\nPress 3 to cancel previous booking:\nPress 4 to exit the system: \n")
    if not booking_choice.isnumeric() or (int(booking_choice) > 4 or int(booking_choice) < 0):
        print("Wrong choice!!")
        BOOKINGS()
    else:
        if booking_choice == "1":
            make_booking()  # Make bookings selection
        elif booking_choice == "2":
            view_booking()  # view of bookings
        elif booking_choice == "3":
            cancel_booking() # the function to cancel database bookings
        elif booking_choice == "4":
            print('\n\n')
            print("Goodbye, thank you for working with us!!!!")
            print('\n\n')
            menu()
        else:
            BOOKINGS()


def login() -> object: #  the login ()
    email = input("Enter your current email: ")
    password = input("Enter your password: ")
    data = (email, password)
    print("\n")
    database = sqlite3.connect('taxdatabase.db')
    connection = database.cursor()
    connection.execute('SELECT * FROM customer WHERE email=? AND password=?', (email, password))
    # shd = connection.execute('SELECT * FROM customer WHERE email=? AND password=?', (email, password))
    # print(shd)
    if connection.fetchone() is not None:
        print(f"Welcome {email}")
        print("\n")
        BOOKINGS()
    else:
        print("Wrong username or password!!")
        print('\n')
        input("Click Enter For More Options!")
        print("\n")
        menu()


def register():  # creting user registration during login
    firstname = input("Enter your firstname: ")
    lastname = input("Enter your lastname: ")
    address = input("Enter your Address: ")
    phone = input("Enter your mobile number: ")
    email = input("Enter your email: ")
    credit_card = input("Enter your credit card info: ")
    city = input("Enter your your current city: ")
    password = input("Enter your password: ")
    confirm_password = input("Confirm your password: ")
    if firstname == "" or lastname == "" or address == "" or phone == "" or email == "" or credit_card == "" or city == "" or password == "" or confirm_password == "":
        print("\n")
        print("Registration not completed!! All fields are required!!!")
        print("\n")
        register()
    elif confirm_password != password:
        print("\n")
        print("Your password does not match!!")
        print("\n")
        register()
    else:
        data = (firstname, lastname, address, phone, email, credit_card, city, password, confirm_password)
        connection = sqlite3.connect('taxdatabase.db')
        cursor = connection.cursor()
        statement = (
            """ INSERT INTO customer (firstname, lastname, address, phone, email, credit_card, city, password, confirm_password) VALUES (?,?,?,?, ?, ?,?,?,?)""")
        cursor.execute(statement, data)
        connection.commit()
        cursor.close()
        print("\n")
        print(f"Greetings {lastname.upper()}, Your account has been created successfully!")
        # droping previous booking upon any registration
        connection = sqlite3.connect('taxdatabase.db')
        cursor = connection.cursor()
        cursor.execute("DROP TABLE IF EXISTS bookingss")
        cursor.execute(
            """CREATE TABLE IF NOT EXISTS bookingss (driver text, address text, destination text, date text, time text)""")
        print("\n")
        input("Click Enter to Procced .....")
        print("\n")
        BOOKINGS()


def menu() -> object:
    selection = input("Press 1 to Login:\nPress 2 to Register:\nPress 4 to Exit:\n\n")
    if not selection.isnumeric() or (int(selection) > 4 or int(selection) < 0):
        print("Wrong choice!")
        menu()  # calling the menu again if there was a wrong selection
    else:
        if selection == '1':
            # selecting the login option
            login()
        elif selection == '2':
            # selecting and calling the register ()
            register()
            print("\n")
        elif selection == '3':
            # calling the menu()
            menu()
        elif selection == '4':
            print('\n\n')
            # exitting the taxi b***king system
            print("Goodbye!!")
            exit()  # the exit()
        else:
            print("Bye!")
            exit(0)  # exit te application


if __name__ == '__main__':  # the main () used to run the taxi b**king system....
    # calling the menu () to display the menu for Login() and Register()
    menu()
