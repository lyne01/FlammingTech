import sqlite3
from sqlite3 import Error
from tabulate import tabulate


# database connection using SQLite module
def create_database():  # () TO CREATE THE DATABASE
    connection = sqlite3.connect('taxdatabase.db')
    cursor = connection.cursor()
    cursor.execute(
        '''CREATE TABLE IF NOT EXISTS customer (firstname text, lastname text, address text, phone text, email text, credit_card text, city text, password text, confirm_password text)''')
    cursor.execute("DROP TABLE IF EXISTS drivers")
    cursor.execute("""CREATE TABLE IF NOT EXISTS drivers (driversname CHAR(20) NOT NULL)""")
    cursor.execute(''' INSERT INTO drivers (driversname) VALUES ('Mr. Right')''')
    cursor.execute(''' INSERT INTO drivers (driversname) VALUES ('Mr. Perfect')''')
    cursor.execute(''' INSERT INTO drivers (driversname) VALUES ('Mr. GoogleMap')''')
    cursor.execute(''' INSERT INTO drivers (driversname) VALUES ('Mr. Route')''')
    cursor.execute(
        """CREATE TABLE IF NOT EXISTS bookingss (driver text, address text, destination text, date text, time text)""")
    connection.commit()
    cursor.close()


def insertdata():  #  the function to insert data in the database***
    connection = sqlite3.connect('taxdatabase.db')
    cursor = connection.cursor()
    sql = (
        """ INSERT INTO bookingss (driver, address, destination, date , time) VALUES (?, ?, ?,?,?)""")
    cursor.execute(sql, datas)
    connection.commit()
    cursor.close()


def bookingdb():  # () to view your database bookings....
    database = sqlite3.connect('taxdatabase.db')
    connection = database.cursor()
    results = connection.execute('SELECT * FROM bookingss')
    print(tabulate(results, headers=['DriverID', 'Address', 'Destination', 'Date', 'Time'], tablefmt='psql'))


def can_bookingdb():  #  The function to cancel databse b**kings
    database = sqlite3.connect('taxdatabase.db')
    connection = database.cursor()
    results = connection.execute('SELECT * FROM bookingss')
    print(tabulate(results, headers=['DriverID', 'Address', 'Destination', 'Date', 'Time'], tablefmt='psql'))
    connection.execute('DELETE FROM bookingss')
    # print("All bookings cancelled successfully!")
    try:
        database.commit()
        database.close()
        input("Press enter to cancelled all bookings!")
        print("All bookings cancelled successfully")
    except:
        print("No Bookings to cancel!! Kindly make bookings")
        print("\n\n")


def registerdb():  # the function to insert data in the database during registration process***
    connection = sqlite3.connect('taxdatabase.db')
    cursor = connection.cursor()
    statement = (
        """ INSERT INTO customer (firstname, lastname, address, phone, email, credit_card, city, password, confirm_password) VALUES (?,?,?,?, ?, ?,?,?,?)""")
    cursor.execute(statement, data)
    connection.commit()
    cursor.close()
