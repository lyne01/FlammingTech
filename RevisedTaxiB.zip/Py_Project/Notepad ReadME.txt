-----------------
TAXIBOOKING SYSTEM

open your CMD and change the directory when the 'anonymous.py' file is located and run this command
"python anonymous.py" and hit Enter!

You can login in if you have an  account of create on for successful bookings

NOTE: the system creates it own SQLite database*****
